﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kafe2
{
    public class Product : Entity
    {
        public string Name { get; private set; }
        public double Price { get; private set; }
        public string Category { get; private set; }

        public Product(string name, double price, string category)
        {
            Name = name;
            Price = price;
            Category = category;
        }
    }
}
