﻿using Kafe2;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

class Program
{
    private const string usersFilePath = "users.txt";
    private const string ordersFilePath = "orders.txt";
    static List<User> users = new List<User>();
    static User loggedInUser = null;

    static List<Product> products = new List<Product>();
    static List<Order> orders = new List<Order>();
    static int Point = 10;

    static void Main(string[] args)
    {
        InitializeProducts();
        users = LoadUsers();
        orders = LoadOrders();

        while (true)
        {
            Console.Clear();
            ShowWelcomeMessage();

            while (true)
            {
                Console.WriteLine("1- Giriş Yap");
                Console.WriteLine("2- Kayıt Ol");
                Console.Write("Seçiminizi yapın: ");
                string initialChoice = Console.ReadLine();

                if (initialChoice == "1")
                {
                    var log = Login();
                    if (log == 0)
                        return;
                    if (log == 1)
                        initialChoice = "2";
                    if (log == 2)
                        break;
                }

                if (initialChoice == "2")
                {
                    var reg = Register();
                    if (reg == 0)
                        return;
                    break;
                }
                else if (initialChoice != "1" && initialChoice != "2")
                {
                    Console.WriteLine("Geçersiz seçim.");
                }
            }

            ShowMainMenu();
        }
    }
    static void InitializeProducts()
    {
        products.Add(new Product("Çay", 15, "İçecekler"));
        products.Add(new Product("Limonata", 20, "İçecekler"));
        products.Add(new Product("Kahve", 25, "İçecekler"));

        products.Add(new Product("Simit", 10, "Atıştırmalıklar"));
        products.Add(new Product("Poğaça", 12, "Atıştırmalıklar"));

        products.Add(new Product("Baklava", 40, "Tatlılar"));
        products.Add(new Product("Pasta", 35, "Tatlılar"));

    }



    static void ShowWelcomeMessage()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("***************************************");
        Console.WriteLine("*           AKILLI KAFE SİSTEMİ       *");
        Console.WriteLine("***************************************");
        Console.ResetColor();
    }

    static int Login()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Giriş Yap");
            Console.WriteLine("Lütfen E-posta ve Şifre bilgilerinizi girin.");
            Console.WriteLine("E-posta:");
            string email = Console.ReadLine();

            Console.WriteLine("Şifre:");
            string password = Console.ReadLine();

            loggedInUser = users.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (loggedInUser != null)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Hoşgeldiniz, {loggedInUser.Name}!");
                Console.ResetColor();
                return 2; // Başarılı giriş
            }

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Hatalı E-posta veya Şifre.");
            Console.ResetColor();
            Console.WriteLine("Tekrar denemek için '1', kayıt olmak için '2', çıkmak için '0' girin:");

            string choice = Console.ReadLine();
            if (choice == "1")
            {
                continue;
            }
            else if (choice == "2")
            {
                return 1; // Kayıt olma seçeneği
            }
            else if (choice == "0")
            {
                return 0; // Çıkış
            }
            else
            {
                Console.WriteLine("Geçersiz seçim, tekrar deneyin.");
            }
        }
    }

    static int Register()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Kayıt Ol");
            Console.WriteLine("Lütfen bilgilerinizi girin:");

            Console.WriteLine("Ad Soyad:");
            string name = Console.ReadLine();

            Console.WriteLine("E-posta:");
            string email = Console.ReadLine();

            if (users.Any(u => u.Email == email))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Bu e-posta adresi zaten kayıtlı. Lütfen farklı bir e-posta girin.");
                Console.ResetColor();
                continue;
            }

            Console.WriteLine("Telefon Numarası:");
            string phone = Console.ReadLine();

            string password;
            while (true)
            {
                Console.WriteLine("Şifre (En az 8 karakter, bir büyük harf, bir küçük harf, bir rakam ve bir özel karakter içermelidir):");
                password = Console.ReadLine();

                string passwordCheck = CheckPasswordStrength(password);
                if (passwordCheck == "Şifre güçlü!")
                {
                    break;
                }

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(passwordCheck);
                Console.ResetColor();
            }

            loggedInUser = new User(name, email, phone, password);
            users.Add(loggedInUser);
            SaveUsers(users);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Kayıt başarılı! Hoşgeldiniz, {loggedInUser.Name}.");
            Console.ResetColor();
            return 2; // Başarılı kayıt
        }
    }

    static string CheckPasswordStrength(string password)
    {
        bool hasUpper = Regex.IsMatch(password, "[A-Z]");
        bool hasLower = Regex.IsMatch(password, "[a-z]");
        bool hasDigit = Regex.IsMatch(password, "[0-9]");
        bool hasSpecialChar = Regex.IsMatch(password, "[!@#$%^&*(),.?\":{}|<>]");
        bool hasMinimumLength = password.Length >= 8;

        if (!hasMinimumLength)
            return "Şifre en az 8 karakter olmalıdır.";
        if (!hasUpper)
            return "Şifre en az bir büyük harf içermelidir.";
        if (!hasLower)
            return "Şifre en az bir küçük harf içermelidir.";
        if (!hasDigit)
            return "Şifre en az bir rakam içermelidir.";
        if (!hasSpecialChar)
            return "Şifre en az bir özel karakter içermelidir.";

        return "Şifre güçlü!";
    }

    static void ShowMainMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("\nAna Menü:");
            Console.WriteLine("1- Menüyü Görüntüle");
            Console.WriteLine("2- Sipariş Ver");
            Console.WriteLine("3- Geçmiş Siparişler");
            Console.WriteLine("4- Çekilişe Katıl");
            Console.WriteLine("5- Çekiliş Sonuçları");
            Console.WriteLine("6- Yıldızlı Müşteriler");
            Console.WriteLine("7- Çıkış");
            Console.Write("\nSeçiminizi yapın: ");

            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    ShowMenu();
                    break;
                case "2":
                    PlaceOrder();
                    break;
                case "3":
                    ShowPastOrders();
                    break;
                case "4":
                    JoinDraw();
                    break;
                case "5":
                    ShowDrawResults();
                    break;
                case "6":
                    ShowStarCustomers();
                    break;
                case "7":
                    loggedInUser = null; // Kullanıcıyı oturumu kapatmak için null yap
                    return; // Giriş ekranına dönmek için döngüden çık
                default:
                    Console.WriteLine("Geçersiz seçim. Tekrar deneyin.");
                    break;
            }
        }
    }
    static void ShowStarCustomers()
    {
        Console.Clear();
        Console.WriteLine("Yıldızlı Müşteriler:");

        // Çekiliş puanını tutan müşterileri filtrele
        var starCustomers = users.Where(u => CalculateUserPoints(u) >= Point).ToList();

        if (!starCustomers.Any())
        {
            Console.WriteLine("Henüz yıldızlı müşteri bulunmuyor.");
        }
        else
        {
            foreach (var customer in starCustomers)
            {
                string participationStatus = customer.InDraw ? "Çekiliş Listesinde" : "Çekiliş Listesinde Değil";
                string participationStatus2 = customer.HasParticipatedInDraw ? "Daha Önce Katıldı" : "Daha Önce Katılmadı";
                Console.WriteLine($"- {customer.Name} ({CalculateUserPoints(customer)} Puan) - Çekiliş Durumu: {participationStatus} - {participationStatus2}");
            }
        }

        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
        Console.ReadKey();
    }


    static void JoinDraw()
    {
        Console.Clear();
        Console.WriteLine("Çekilişe Katıl:");

        // Kullanıcının toplam puanını hesapla
        int totalPoints = CalculateUserPoints(loggedInUser);

        Console.WriteLine($"Toplam Puanınız: {totalPoints}");
        if (loggedInUser.InDraw || loggedInUser.HasParticipatedInDraw)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Zaten çekilişe katıldınız. Birden fazla kez katılamazsınız.");
            Console.ResetColor();
        }
        else if (totalPoints >= Point)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Tebrikler! Çekilişe katıldınız.");
            //loggedInUser.HasParticipatedInDraw = true; // Kullanıcıyı çekilişe katılmış olarak işaretle
            loggedInUser.InDraw = true;
            SaveUsers(users); // Değişikliği kaydet
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Puanınız yetersiz. Çekilişe katılmak için {Point} puan veya daha fazlasına ihtiyacınız var.");
            Console.ResetColor();
        }

        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
        Console.ReadKey();
    }

    static void ShowDrawResults()
    {
        Console.Clear();
        Console.WriteLine("Çekiliş Sonuçları:");

        // Çekilişe katılmaya uygun kullanıcıları filtrele
        var eligibleUsers = users.Where(u => CalculateUserPoints(u) >= Point && u.InDraw && !u.HasParticipatedInDraw).ToList();

        if (!eligibleUsers.Any())
        {
            Console.WriteLine("Çekilişe katılmaya uygun kullanıcı bulunamadı.");
        }
        else
        {
            foreach (var item in eligibleUsers)
            {
                item.HasParticipatedInDraw = true;
                item.InDraw = false;
                SaveUsers(users);
            }
            // Rastgele bir kazanan seç
            Random random = new Random();
            var winner = eligibleUsers[random.Next(eligibleUsers.Count)];

            // Rastgele bir içecek ve tatlı seç
            var drinks = products.Where(p => p.Category == "İçecekler").ToList();
            var sweets = products.Where(p => p.Category == "Tatlılar").ToList();
            var randomDrink = drinks[random.Next(drinks.Count)];
            var randomSweet = sweets[random.Next(sweets.Count)];

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Kazanan: {winner.Name}");
            Console.WriteLine($"Hediye: {randomDrink.Name} ve {randomSweet.Name}");
            Console.ResetColor();

            // Kazananın puanlarını sıfırla ve katılmış olarak işaretle
            
            // Güncellenen kullanıcıyı kaydet
        }

        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
        Console.ReadKey();
    }

    static int CalculateUserPoints(User user)
    {
        // Kullanıcının tüm siparişlerini bul
        var userOrders = orders.Where(o => o.User.Email == user.Email).ToList();

        // Siparişlerin toplamından puan hesapla (örneğin toplam tutar/10)
        int totalPoints = userOrders.Sum(o => (int)(o.TotalPrice / 10));
        return totalPoints;
    }

    static void ShowMenu()
    {
        Console.Clear();
        Console.WriteLine("\nMenü:");
        var groupedProducts = products.GroupBy(p => p.Category);
        foreach (var category in groupedProducts)
        {
            Console.WriteLine($"\n{category.Key}:");
            foreach (var product in category)
            {
                Console.WriteLine($"- {product.Name} - {product.Price.ToString("F2")}TL");
            }
        }
        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
        Console.ReadKey();
    }

    static void PlaceOrder()
    {
        List<OrderItem> cart = new List<OrderItem>();

        while (true)
        {
            Console.Clear();
            Console.WriteLine("Sipariş Ver:");

            int globalIndex = 1;
            var groupedProducts = products.GroupBy(p => p.Category);

            foreach (var category in groupedProducts)
            {
                Console.WriteLine($"\n{category.Key}:");
                foreach (var product in category)
                {
                    Console.WriteLine($"{globalIndex++}- {product.Name} - {product.Price:F2} TL");
                }
            }

            Console.WriteLine("\nSepeti görüntülemek için 'S', ürünü silmek için 'R', siparişi tamamlamak için 'C', geri dönmek için 'Q' yazın.");
            Console.Write("Seçiminizi yapın: ");
            string choice = Console.ReadLine();

            if (choice.ToUpper() == "C")
            {
                CompleteOrder(cart);
                break;
            }
            else if (choice.ToUpper() == "Q")
            {
                break;
            }
            else if (choice.ToUpper() == "S")
            {
                DisplayCart(cart);
                Console.WriteLine("\nDevam etmek için bir tuşa basın...");
                Console.ReadKey();
            }
            else if (choice.ToUpper() == "R")
            {
                Console.WriteLine("Silmek istediğiniz ürünün adını yazın:");
                string productName = Console.ReadLine();
                var itemToRemove = cart.FirstOrDefault(i => i.Product.Name.Equals(productName, StringComparison.OrdinalIgnoreCase));
                if (itemToRemove != null)
                {
                    cart.Remove(itemToRemove);
                    Console.WriteLine("Ürün sepetten silindi.");
                }
                else
                {
                    Console.WriteLine("Ürün sepette bulunamadı.");
                }
                Console.ReadKey();
            }
            else if (int.TryParse(choice, out int productIndex) && productIndex > 0 && productIndex <= products.Count)
            {
                var selectedProduct = products[productIndex - 1];
                var existingItem = cart.FirstOrDefault(i => i.Product == selectedProduct);
                if (existingItem != null)
                {
                    existingItem.Quantity++;
                }
                else
                {
                    //cart.Add(new OrderItem { Product = selectedProduct, Quantity = 1 });
                    cart.Add(new OrderItem(selectedProduct, 1));
                }
                Console.WriteLine($"Sepete eklendi: {selectedProduct.Name}");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Geçersiz seçim, tekrar deneyin.");
                Console.ReadKey();
            }
        }
    }

    static void DisplayCart(List<OrderItem> cart)
    {
        Console.Clear();
        Console.WriteLine("\nSepetiniz:");
        foreach (var item in cart)
        {
            Console.WriteLine($"{item.Product.Name} x{item.Quantity} - Toplam: {item.Product.Price * item.Quantity:F2} TL");
        }
        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
    }

    static void CompleteOrder(List<OrderItem> cart)
    {
        if (cart.Count == 0)
        {
            Console.WriteLine("Sepetiniz boş. Sipariş vermek için ürün ekleyin.");
            Console.ReadKey();
            return;
        }

        double totalPrice = cart.Sum(item => item.Product.Price * item.Quantity);



        var xx = new Order(loggedInUser, new List<OrderItem>(cart));
        orders.Add(xx);
        SaveOrders(orders);

        Console.WriteLine("\nSipariş Tamamlandı:");
        DisplayCart(cart);
        Console.WriteLine($"Toplam Tutar: {totalPrice:F2} TL");
        Console.WriteLine("Devam etmek için bir tuşa basın...");
        Console.ReadKey();
    }

    static void ShowPastOrders()
    {
        Console.Clear();
        Console.WriteLine("Geçmiş Siparişleriniz:");

        // Kullanıcının siparişlerini filtrele
        var userOrders = orders.Where(o => o.User.Email == loggedInUser.Email).ToList();

        if (!userOrders.Any())
        {
            Console.WriteLine("Henüz geçmiş siparişiniz yok.");
        }
        else
        {
            // Her sipariş için detayları listele
            foreach (var order in userOrders)
            {
                Console.WriteLine("\nSipariş:");
                foreach (var item in order.Items)
                {
                    Console.WriteLine($"- {item.Product.Name} x{item.Quantity} - {item.Product.Price * item.Quantity:F2} TL");
                }
                Console.WriteLine($"Toplam: {order.TotalPrice:F2} TL");
                Console.WriteLine("------------------------------------");
            }
        }

        Console.WriteLine("\nDevam etmek için bir tuşa basın...");
        Console.ReadKey();
    }


    static List<User> LoadUsers()
    {
        if (File.Exists(usersFilePath))
        {
            string json = File.ReadAllText(usersFilePath);
            return JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
        }
        return new List<User>();
    }

    static List<Order> LoadOrders()
    {
        if (File.Exists(ordersFilePath))
        {
            string json = File.ReadAllText(ordersFilePath);
            return JsonConvert.DeserializeObject<List<Order>>(json) ?? new List<Order>();
        }
        return new List<Order>();
    }

    static void SaveOrders(List<Order> orders)
    {
        string json = JsonConvert.SerializeObject(orders);
        File.WriteAllText(ordersFilePath, json);
    }


    static void SaveUsers(List<User> users)
    {
        string json = JsonConvert.SerializeObject(users);
        File.WriteAllText(usersFilePath, json);
    }

}